﻿
namespace L9_JRRA_1087121
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_modelo = new System.Windows.Forms.Label();
            this.lbl_marca = new System.Windows.Forms.Label();
            this.lbl_dolar = new System.Windows.Forms.Label();
            this.lbl_precio = new System.Windows.Forms.Label();
            this.lbl_disponible = new System.Windows.Forms.Label();
            this.lbl_descuento = new System.Windows.Forms.Label();
            this.lbl_automovil = new System.Windows.Forms.Label();
            this.text_modelo = new System.Windows.Forms.TextBox();
            this.text_dolar = new System.Windows.Forms.TextBox();
            this.text_precio = new System.Windows.Forms.TextBox();
            this.text_marca = new System.Windows.Forms.TextBox();
            this.text_disponible = new System.Windows.Forms.TextBox();
            this.text_descuento = new System.Windows.Forms.TextBox();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.lmp_limpiar = new System.Windows.Forms.Button();
            this.lbl_datos = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_modelo
            // 
            this.lbl_modelo.AutoSize = true;
            this.lbl_modelo.Location = new System.Drawing.Point(117, 156);
            this.lbl_modelo.Name = "lbl_modelo";
            this.lbl_modelo.Size = new System.Drawing.Size(54, 17);
            this.lbl_modelo.TabIndex = 0;
            this.lbl_modelo.Text = "Modelo";
            // 
            // lbl_marca
            // 
            this.lbl_marca.AutoSize = true;
            this.lbl_marca.Location = new System.Drawing.Point(117, 244);
            this.lbl_marca.Name = "lbl_marca";
            this.lbl_marca.Size = new System.Drawing.Size(47, 17);
            this.lbl_marca.TabIndex = 1;
            this.lbl_marca.Text = "Marca";
            // 
            // lbl_dolar
            // 
            this.lbl_dolar.AutoSize = true;
            this.lbl_dolar.Location = new System.Drawing.Point(321, 156);
            this.lbl_dolar.Name = "lbl_dolar";
            this.lbl_dolar.Size = new System.Drawing.Size(121, 17);
            this.lbl_dolar.TabIndex = 2;
            this.lbl_dolar.Text = "Tipo cambio dolar";
            // 
            // lbl_precio
            // 
            this.lbl_precio.AutoSize = true;
            this.lbl_precio.Location = new System.Drawing.Point(117, 335);
            this.lbl_precio.Name = "lbl_precio";
            this.lbl_precio.Size = new System.Drawing.Size(48, 17);
            this.lbl_precio.TabIndex = 3;
            this.lbl_precio.Text = "Precio";
            // 
            // lbl_disponible
            // 
            this.lbl_disponible.AutoSize = true;
            this.lbl_disponible.Location = new System.Drawing.Point(321, 244);
            this.lbl_disponible.Name = "lbl_disponible";
            this.lbl_disponible.Size = new System.Drawing.Size(74, 17);
            this.lbl_disponible.TabIndex = 4;
            this.lbl_disponible.Text = "Disponible";
            // 
            // lbl_descuento
            // 
            this.lbl_descuento.AutoSize = true;
            this.lbl_descuento.Location = new System.Drawing.Point(321, 335);
            this.lbl_descuento.Name = "lbl_descuento";
            this.lbl_descuento.Size = new System.Drawing.Size(133, 17);
            this.lbl_descuento.TabIndex = 5;
            this.lbl_descuento.Text = "Descuento aplicado";
            // 
            // lbl_automovil
            // 
            this.lbl_automovil.AutoSize = true;
            this.lbl_automovil.Location = new System.Drawing.Point(347, 65);
            this.lbl_automovil.Name = "lbl_automovil";
            this.lbl_automovil.Size = new System.Drawing.Size(69, 17);
            this.lbl_automovil.TabIndex = 6;
            this.lbl_automovil.Text = "Automovil";
            // 
            // text_modelo
            // 
            this.text_modelo.Location = new System.Drawing.Point(120, 189);
            this.text_modelo.Name = "text_modelo";
            this.text_modelo.Size = new System.Drawing.Size(100, 22);
            this.text_modelo.TabIndex = 7;
            // 
            // text_dolar
            // 
            this.text_dolar.Location = new System.Drawing.Point(324, 189);
            this.text_dolar.Name = "text_dolar";
            this.text_dolar.Size = new System.Drawing.Size(100, 22);
            this.text_dolar.TabIndex = 8;
            // 
            // text_precio
            // 
            this.text_precio.Location = new System.Drawing.Point(120, 365);
            this.text_precio.Name = "text_precio";
            this.text_precio.Size = new System.Drawing.Size(100, 22);
            this.text_precio.TabIndex = 9;
            // 
            // text_marca
            // 
            this.text_marca.Location = new System.Drawing.Point(120, 273);
            this.text_marca.Name = "text_marca";
            this.text_marca.Size = new System.Drawing.Size(100, 22);
            this.text_marca.TabIndex = 10;
            // 
            // text_disponible
            // 
            this.text_disponible.Location = new System.Drawing.Point(324, 273);
            this.text_disponible.Name = "text_disponible";
            this.text_disponible.Size = new System.Drawing.Size(100, 22);
            this.text_disponible.TabIndex = 11;
            // 
            // text_descuento
            // 
            this.text_descuento.Location = new System.Drawing.Point(324, 365);
            this.text_descuento.Name = "text_descuento";
            this.text_descuento.Size = new System.Drawing.Size(100, 22);
            this.text_descuento.TabIndex = 12;
            // 
            // btn_guardar
            // 
            this.btn_guardar.Location = new System.Drawing.Point(524, 238);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(75, 23);
            this.btn_guardar.TabIndex = 13;
            this.btn_guardar.Text = "Guardar";
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);
            // 
            // lmp_limpiar
            // 
            this.lmp_limpiar.Location = new System.Drawing.Point(524, 329);
            this.lmp_limpiar.Name = "lmp_limpiar";
            this.lmp_limpiar.Size = new System.Drawing.Size(75, 23);
            this.lmp_limpiar.TabIndex = 14;
            this.lmp_limpiar.Text = "Limpiar";
            this.lmp_limpiar.UseVisualStyleBackColor = true;
            this.lmp_limpiar.Click += new System.EventHandler(this.lmp_limpiar_Click);
            // 
            // lbl_datos
            // 
            this.lbl_datos.AutoSize = true;
            this.lbl_datos.Location = new System.Drawing.Point(669, 194);
            this.lbl_datos.Name = "lbl_datos";
            this.lbl_datos.Size = new System.Drawing.Size(119, 17);
            this.lbl_datos.TabIndex = 15;
            this.lbl_datos.Text = "Datos Ingresados";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_datos);
            this.Controls.Add(this.lmp_limpiar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.text_descuento);
            this.Controls.Add(this.text_disponible);
            this.Controls.Add(this.text_marca);
            this.Controls.Add(this.text_precio);
            this.Controls.Add(this.text_dolar);
            this.Controls.Add(this.text_modelo);
            this.Controls.Add(this.lbl_automovil);
            this.Controls.Add(this.lbl_descuento);
            this.Controls.Add(this.lbl_disponible);
            this.Controls.Add(this.lbl_precio);
            this.Controls.Add(this.lbl_dolar);
            this.Controls.Add(this.lbl_marca);
            this.Controls.Add(this.lbl_modelo);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_modelo;
        private System.Windows.Forms.Label lbl_marca;
        private System.Windows.Forms.Label lbl_dolar;
        private System.Windows.Forms.Label lbl_precio;
        private System.Windows.Forms.Label lbl_disponible;
        private System.Windows.Forms.Label lbl_descuento;
        private System.Windows.Forms.Label lbl_automovil;
        private System.Windows.Forms.TextBox text_modelo;
        private System.Windows.Forms.TextBox text_dolar;
        private System.Windows.Forms.TextBox text_precio;
        private System.Windows.Forms.TextBox text_marca;
        private System.Windows.Forms.TextBox text_disponible;
        private System.Windows.Forms.TextBox text_descuento;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Button lmp_limpiar;
        private System.Windows.Forms.Label lbl_datos;
    }
}

