﻿using System;

namespace T7_JRRA_1087121
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Tarea Laboratorio #7");
                Console.WriteLine("");
                Console.WriteLine("José Roberto Rodríguez // 1087121");
                Console.WriteLine("");
                Console.WriteLine("Ingrese un número entero mayor a cero");
                Console.WriteLine("");
            }
            catch
            {
                Console.WriteLine("");
                Console.WriteLine("Debe un número entero mayor a cero");
                Console.WriteLine("");
            }
        }
    }
}
